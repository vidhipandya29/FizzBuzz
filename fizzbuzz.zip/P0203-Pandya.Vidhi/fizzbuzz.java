
/**
 * Write a description of class fizzbuzz here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
//
public class fizzbuzz
{
    public static void main (String args [])
    {
        new fizzbuzz ();
    }
    
    public fizzbuzz ()
    {
        //Ask user to pick a number
        int t = IBIO.inputInt ("Choose a number");
        //Create a loop that counts up to the number inputted by the user
        for (int i = 1 ; i<=t ; i++)
        {
            //If the inputted number is divisible by 3 and 5, it should print FizzBuzz
            if ((i%3==0) && (i%5==0))
            {
                System.out.print ("FizzBuzz ");
            }
            //If the inputted number is divisible by 3, it should print Fizz
            else if (i%3==0)
            {
                System.out.print ("Fizz ");
            }
            //If the inputted number is divisible by 5, it should print Buzz
            else if (i%5==0)
            {
                System.out.print ("Buzz ");
            }
            //If the inputted number is not divisible by 3 or 5, it should print a space
            else
            {
                System.out.print (i + " ");
            }
        }
    }
}

